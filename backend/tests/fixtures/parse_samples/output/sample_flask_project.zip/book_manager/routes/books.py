"""Book Management Routes."""
from flask import Blueprint, request, jsonify
from flask_login import login_required
from ..models import Book, Category, db

books_bp = Blueprint("books", __name__, url_prefix="/api/books")


@books_bp.route("/", methods=["GET"])
def list_books():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    query = request.args.get("q", "")

    books_query = Book.query
    if query:
        books_query = books_query.filter(
            Book.title.ilike(f"%{query}%") | Book.author.ilike(f"%{query}%")
        )

    pagination = books_query.paginate(page=page, per_page=per_page)
    return jsonify({
        "items": [
            {
                "id": b.id,
                "title": b.title,
                "author": b.author,
                "isbn": b.isbn,
                "available": b.available_copies,
                "category": b.category.name if b.category else None,
            }
            for b in pagination.items
        ],
        "total": pagination.total,
        "pages": pagination.pages,
        "current_page": page,
    })


@books_bp.route("/", methods=["POST"])
@login_required
def create_book():
    data = request.get_json()
    book = Book(
        title=data["title"],
        author=data["author"],
        isbn=data.get("isbn"),
        total_copies=data.get("total_copies", 1),
        available_copies=data.get("total_copies", 1),
        description=data.get("description"),
        category_id=data.get("category_id"),
    )
    db.session.add(book)
    db.session.commit()
    return jsonify({"id": book.id, "title": book.title}), 201
