"""Borrow Management Routes."""
from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from ..models import Book, BorrowRecord, db

borrow_bp = Blueprint("borrow", __name__, url_prefix="/api/borrow")


@borrow_bp.route("/", methods=["POST"])
@login_required
def borrow_book():
    data = request.get_json()
    book_id = data.get("book_id")

    book = Book.query.get_or_404(book_id)
    if book.available_copies <= 0:
        return jsonify({"error": "No copies available"}), 400

    # Check if user already has this book
    existing = BorrowRecord.query.filter_by(
        user_id=current_user.id, book_id=book_id, status="borrowed"
    ).first()
    if existing:
        return jsonify({"error": "Already borrowed this book"}), 400

    record = BorrowRecord(user_id=current_user.id, book_id=book_id)
    book.available_copies -= 1
    db.session.add(record)
    db.session.commit()

    return jsonify({
        "id": record.id,
        "book": book.title,
        "due_date": record.due_date.isoformat(),
    }), 201


@borrow_bp.route("/<int:record_id>/return", methods=["POST"])
@login_required
def return_book(record_id):
    record = BorrowRecord.query.get_or_404(record_id)
    if record.user_id != current_user.id:
        return jsonify({"error": "Not your borrow record"}), 403
    if record.status == "returned":
        return jsonify({"error": "Already returned"}), 400

    record.status = "returned"
    record.return_date = datetime.utcnow()
    record.book.available_copies += 1
    db.session.commit()

    return jsonify({"message": "Book returned successfully"})
