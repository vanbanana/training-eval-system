# Book Manager

A Flask-based library management system.

## Setup
```bash
pip install -r requirements.txt
flask db upgrade
flask run
```

## Features
- User authentication
- Book CRUD
- Borrow/Return management
- Search functionality
