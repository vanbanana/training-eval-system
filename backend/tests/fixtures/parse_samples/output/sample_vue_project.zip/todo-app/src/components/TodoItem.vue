<script setup lang="ts">
import type { Todo } from "../stores/todo"

defineProps<{ todo: Todo }>()
defineEmits<{ toggle: []; remove: [] }>()

const priorityColors = {
  low: "bg-green-100 text-green-800",
  medium: "bg-yellow-100 text-yellow-800",
  high: "bg-red-100 text-red-800",
}
</script>

<template>
  <div class="flex items-center gap-3 p-3 border rounded hover:bg-gray-50">
    <input
      type="checkbox"
      :checked="todo.completed"
      @change="$emit('toggle')"
      class="w-5 h-5"
    />
    <span :class="{ 'line-through text-gray-400': todo.completed }" class="flex-1">
      {{ todo.title }}
    </span>
    <span :class="priorityColors[todo.priority]" class="text-xs px-2 py-1 rounded">
      {{ todo.priority }}
    </span>
    <button @click="$emit('remove')" class="text-red-400 hover:text-red-600">
      &times;
    </button>
  </div>
</template>
