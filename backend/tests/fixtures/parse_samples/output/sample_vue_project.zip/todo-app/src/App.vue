<template>
  <div class="min-h-screen bg-gray-100">
    <nav class="bg-white shadow-sm">
      <div class="max-w-4xl mx-auto px-4 py-3">
        <h1 class="text-xl font-bold text-gray-800">Todo App</h1>
      </div>
    </nav>
    <main class="max-w-4xl mx-auto px-4 py-8">
      <router-view />
    </main>
  </div>
</template>
