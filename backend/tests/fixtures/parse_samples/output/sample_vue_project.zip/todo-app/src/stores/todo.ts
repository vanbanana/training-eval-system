import { defineStore } from "pinia"
import { ref, computed } from "vue"

export interface Todo {
  id: number
  title: string
  completed: boolean
  createdAt: Date
  priority: "low" | "medium" | "high"
}

export const useTodoStore = defineStore("todo", () => {
  const todos = ref<Todo[]>([])
  let nextId = 1

  const completedCount = computed(() =>
    todos.value.filter((t) => t.completed).length
  )

  const pendingCount = computed(() =>
    todos.value.filter((t) => !t.completed).length
  )

  function addTodo(title: string, priority: Todo["priority"] = "medium") {
    todos.value.push({
      id: nextId++,
      title,
      completed: false,
      createdAt: new Date(),
      priority,
    })
  }

  function toggleTodo(id: number) {
    const todo = todos.value.find((t) => t.id === id)
    if (todo) {
      todo.completed = !todo.completed
    }
  }

  function removeTodo(id: number) {
    todos.value = todos.value.filter((t) => t.id !== id)
  }

  function clearCompleted() {
    todos.value = todos.value.filter((t) => !t.completed)
  }

  return { todos, completedCount, pendingCount, addTodo, toggleTodo, removeTodo, clearCompleted }
})
