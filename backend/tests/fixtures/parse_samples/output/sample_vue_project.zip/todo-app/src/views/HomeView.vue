<script setup lang="ts">
import { ref } from "vue"
import { useTodoStore } from "../stores/todo"
import TodoItem from "../components/TodoItem.vue"

const store = useTodoStore()
const newTitle = ref("")
const newPriority = ref<"low" | "medium" | "high">("medium")

function handleAdd() {
  if (newTitle.value.trim()) {
    store.addTodo(newTitle.value.trim(), newPriority.value)
    newTitle.value = ""
  }
}
</script>

<template>
  <div class="space-y-6">
    <div class="bg-white rounded-lg shadow p-6">
      <h2 class="text-lg font-semibold mb-4">Add New Todo</h2>
      <form @submit.prevent="handleAdd" class="flex gap-3">
        <input
          v-model="newTitle"
          type="text"
          placeholder="What needs to be done?"
          class="flex-1 border rounded px-3 py-2"
        />
        <select v-model="newPriority" class="border rounded px-3 py-2">
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">
          Add
        </button>
      </form>
    </div>

    <div class="bg-white rounded-lg shadow p-6">
      <div class="flex justify-between items-center mb-4">
        <h2 class="text-lg font-semibold">
          Todos ({{ store.pendingCount }} pending)
        </h2>
        <button
          v-if="store.completedCount > 0"
          @click="store.clearCompleted()"
          class="text-sm text-red-500"
        >
          Clear completed ({{ store.completedCount }})
        </button>
      </div>
      <div class="space-y-2">
        <TodoItem
          v-for="todo in store.todos"
          :key="todo.id"
          :todo="todo"
          @toggle="store.toggleTodo(todo.id)"
          @remove="store.removeTodo(todo.id)"
        />
        <p v-if="store.todos.length === 0" class="text-gray-400 text-center py-8">
          No todos yet. Add one above!
        </p>
      </div>
    </div>
  </div>
</template>
